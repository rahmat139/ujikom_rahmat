<?php
$koneksi = mysqli_connect("localhost", "root", "", "rahmat_appem_kel2");


?>