<?php
//untuk memanggil method koneksi
require '../koneksi.php';

// variabel itu seperti wadah untuk menyimpan sesuatu ($)
$nik=$_GET['nik'];


//untuk mengambil semua data berdasarkan username yang di inputkan oleh user
$sql=mysqli_query($koneksi, "DELETE FROM masyarakat WHERE nik='$nik'");

if ($sql)
{
    ?>
    <script type="text/javascript">
        alert ('Data Berhasil Dihapus');
        window.location='admin.php?url=lihat_masyarakat';
    </script>

<?php
}


?>
<!-- query  -->
<!-- menjalankan tindakan sesuai pesanan. -->

<!-- method -->
<!-- fungsi yang dapat dikerjakan oleh suatu object. -->

<!-- Variabel POST untuk memasukan -->
<!-- Variabel GET untuk mengambil -->
<!-- Variabel SET untuk seting atau mengatur -->

<!-- Atribut adalah informasi tambahan yang diberikan kepada tag -->